(window.webpackJsonp=window.webpackJsonp||[]).push([[13],{290:function(e,s,t){"use strict";t.r(s);var a=t(0),r=t(3);t(150),customElements.define("ha-panel-kiosk",class extends r.a{static get template(){return a["a"]`
    <partial-cards
      id='kiosk-states'
      hass='[[hass]]'
      show-menu
      route='[[route]]'
      panel-visible
    ></partial-cards>
    `}static get properties(){return{hass:Object,route:Object}}})}}]);
//# sourceMappingURL=66ba899cb85587368483.chunk.js.map